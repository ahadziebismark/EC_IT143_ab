-- Step 6: Ask the next question
-- How can I track who last modified the record?
ALTER TABLE dbo.t_w3_schools_customers ADD LastModifiedBy NVARCHAR(100);

CREATE TRIGGER trg_UpdateLastModifiedBy
ON dbo.t_w3_schools_customers
AFTER UPDATE
AS
BEGIN
    UPDATE c
    SET LastModifiedBy = SUSER_SNAME()
    FROM dbo.t_w3_schools_customers c
    INNER JOIN inserted i ON c.CustomerID = i.CustomerID;
END;
