-- Step 4: Create an after-update trigger
ALTER TABLE dbo.t_w3_schools_customers ADD LastModifiedDate DATETIME;

CREATE TRIGGER trg_UpdateLastModifiedDate
ON dbo.t_w3_schools_customers
AFTER UPDATE
AS
BEGIN
    UPDATE c
    SET LastModifiedDate = GETDATE()
    FROM dbo.t_w3_schools_customers c
    INNER JOIN inserted i ON c.CustomerID = i.CustomerID;
END;
