-- Step 5: Test trigger result
UPDATE dbo.t_w3_schools_customers
SET City = City -- no actual change
WHERE CustomerID = 1;

SELECT CustomerID, LastModifiedDate
FROM dbo.t_w3_schools_customers
WHERE CustomerID = 1;
