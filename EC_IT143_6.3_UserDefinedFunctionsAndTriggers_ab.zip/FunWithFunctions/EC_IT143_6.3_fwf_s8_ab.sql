-- Step 8: Ask the next question
-- How can I extract the last name from the ContactName field?
CREATE FUNCTION dbo.fn_GetLastName (@FullName NVARCHAR(100))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @LastName NVARCHAR(50);
    SET @LastName = LTRIM(RIGHT(@FullName, LEN(@FullName) - CHARINDEX(' ', @FullName + ' ')));
    RETURN @LastName;
END;
