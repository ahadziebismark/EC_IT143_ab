-- Step 5: Create a user-defined scalar function
CREATE FUNCTION dbo.fn_GetFirstName (@FullName NVARCHAR(100))
RETURNS NVARCHAR(50)
AS
BEGIN
    DECLARE @FirstName NVARCHAR(50);
    SET @FirstName = SUBSTRING(@FullName, 1, CHARINDEX(' ', @FullName + ' ') - 1);
    RETURN @FirstName;
END;
