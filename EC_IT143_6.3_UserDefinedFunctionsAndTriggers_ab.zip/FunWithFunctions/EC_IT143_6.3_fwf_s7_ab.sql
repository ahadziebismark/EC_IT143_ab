-- Step 7: Perform a “0 results expected” test
WITH CTE AS (
    SELECT ContactName
    FROM dbo.t_w3_schools_customers
    WHERE dbo.fn_GetFirstName(ContactName) IS NULL
)
SELECT * FROM CTE;
