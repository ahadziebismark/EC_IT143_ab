-- Step 6: Compare UDF results to ad hoc query results
SELECT ContactName,
       dbo.fn_GetFirstName(ContactName) AS FirstName_UDF,
       SUBSTRING(ContactName, 1, CHARINDEX(' ', ContactName) - 1) AS FirstName_AdHoc
FROM dbo.t_w3_schools_customers;
